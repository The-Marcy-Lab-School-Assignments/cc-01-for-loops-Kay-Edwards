//1
function morningLogged(){
  console.log('Good Morning');
}

//2
function iLoveCode(){
  return 'I love code challenges';
}

//3
function loggingTwice(){
  console.log('one');
  console.log('two');
}

//4
function noStep(){
  console.log('one');
  return 'two';
  console.log(step);
}

//5
function isPrime(){
  
}


morningLogged();
console.log(iLoveCode());
loggingTwice();
noStep();